************************************************************************************

Note :
	(*) All the frm, frx, vbp, vbw named COLCE2020F056 files are reqiured.
	(*) The executed exe file named as "COLCE2020F056 - Executed Program.exe".


****
COL/CE/2020/F/056 K.R.MADHUSHANKHA
RavinduMadhushankha@gmail.com